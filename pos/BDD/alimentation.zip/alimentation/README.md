**LIEN DE SITE HEBERGE**
https://almgttechnolabprojet.000webhostapp.com/

**Admin Login Detailss**

Email : admin@mail.com

Mot de passe: 123456

**Caissier Login Details**

Email : cashier@mail.com

Mot de passe: 123456

**Client Login Details**

Email : Client@mail.com

Mot de passe: 123456
