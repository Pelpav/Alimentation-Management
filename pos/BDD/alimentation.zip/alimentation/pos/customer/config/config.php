<?php
$dbuser = "tomglobalb";
$dbpass = "3PbDyeAhNS";
$host = "localhost";
$db = "tomglobalb_alimentation";
$mysqli = new mysqli($host, $dbuser, $dbpass, $db);
?>
